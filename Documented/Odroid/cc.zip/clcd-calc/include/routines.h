#ifndef _ROUTINES_H
#define _ROUTINES_H

void setup();
void loop();

#endif /* _ROUTINES_H */
